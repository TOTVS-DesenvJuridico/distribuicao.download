import { PoTableColumn } from "@po-ui/ng-components";

/**
 * Estrutura do Grid para Faturas Adicionais ( Visualização )
 */
export const gridFaturaAdicional: Array<PoTableColumn> = [
	{
		property: "codigo",
		label: "Código",
	},
	{
		property: "database",
		label: "Data base",
	},
	{
		property: "descGrupo",
		label: "Grupo de clientes",
		visible: false,
	},
	{
		property: "codCliente",
		label: "Código cliente",
		visible: false
	},{
		property: "lojaCliente",
		label: "Loja cliente",
		visible: false
	},{
		property: "cliente",
		label: "Cliente",
	},
	{
		property: "codContrato",
		label: "Código contrato",
		visible: false
	},{
		property: "nomeContrato",
		label: "Contrato",
	},
	{
		property: "valorTS",
		label: "Valor TS",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "valorTabelado",
		label: "Valor tabelado",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "valorDespesa",
		label: "Valor despesa",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "valorTotal",
		label: "Valor total",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "faturaAdicionalOcorrencia",
		label: "Ocorrência",
		type: "boolean",
	},
];

/**
 * Estrutura do Grid para Fatura ( Visualização )
 */
export const gridFatura: Array<PoTableColumn> = [
	{
		property: "codigo",
		label: "Código",
	},
	{
		property: "codigoEscritorio",
		label: "Código escritório",
		visible: false,
	},
	{
		property: "descEscritorio",
		label: "Escritório",
	},
	{
		property: "quantidadeTitulosReceber",
		label: "Quant. títulos receber",
		type: "number",
		visible: false,
	},
	{
		property: "dataEmissao",
		label: "Data de emissão",
	},
	{
		property: "codMoeda",
		label: "Código moeda",
		visible: false,
	},
	{
		property: "descMoeda",
		label: "Moeda",
	},
	{
		property: "valorHonorario",
		label: "Valor de honorários",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "valorDespesas",
		label: "Valor de despesas",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "saldoFatura",
		label:"Saldo fatura",
		format: "1.2-2",
		type: "number",
		visible: false
	},{
		property: "codParticipante",
		label: "Código Participante",
		visible: false,
	},
	{
		property: "siglaParticipante",
		label: "Sigla",
		visible: false,
	},
	{
		property: "nomeParticipante",
		label: "Participante",
		visible: false,
	},
];

/**
 * Estrutura do Grid para Timesheet ( Visualização )
 */
export const gridTimesheet: Array<PoTableColumn> = [
	{
		property: "codigo",
		label: "Código",
	},
	{
		property: "data",
		label: "Data",
	},
	{
		property: "codSolicitante",
		label: "Código part. lançado",
		visible: false,
	},
	{
		property: "siglaSolicitante",
		label: "Sigla part. lançado",
	},
	{
		property: "nomeSolicitante",
		label: "Nome part. lançado",
		visible: false,
	},
	{
		property: "codRevisor",
		label: "Código revisado",
		visible: false,
	},
	{
		property: "siglaRevisor",
		label: "Sigla revisado",
	},
	{
		property: "nomeRevisor",
		label: "Nome revisado",
		visible: false,
	},
	{
		property: "codCliente",
		label: "Código cliente",
		visible: false,
	},
	{
		property: "lojaCliente",
		label: "Loja cliente",
		visible: false,
	},
	{
		property: "cliente",
		label: "Cliente",
	},
	{
		property: "codCaso",
		label: "Código do caso",
		visible: false,
	},
	{
		property: "tituloCaso",
		label: "Título do caso",
	},
	{
		property: "codAtividade",
		label: "Código atividade",
		visible: false,
	},
	{
		property: "descAtividade",
		label: "Atividade",
	},
	{
		property: "horaLancada",
		label: "Hora lançada",
	},
	{
		property: "horaRevisada",
		label: "Hora revisada",
	},
	{
		property: "UTLancada",
		label: "UT lançada",
		visible: false,
	},
	{
		property: "UTRevisada",
		label: "UT revisada",
		visible: false,
	},
	{
		property: "cobrar",
		label: "Cobrar",
		type: "boolean",
	},
	{
		property: "codMoeda",
		label: "Código moeda",
		visible: false,
	},
	{
		property: "simboloMoeda",
		label: "Simb. moeda",
		visible: false,
	},
	{
		property: "descMoeda",
		label: "Moeda",
	},
	{
		property: "valorTS",
		label: "Valor",
		format: "1.2-2",
		type: "number",
	},
	{
		property: "descricTS",
		label: "Descrição",
		visible: false,
	},
];

/**
 * Estrutura do Grid para Pré faturas ( Alteração )
 */
export const gridPreFaturas: Array<PoTableColumn> = [
	{
		property: "codigo",
		label: "Número pré-fatura",
	},
	{
		property: "situacao",
		label: "Situação",
	},
	{
		property: "dataEmissao",
		label: "Data emissão",
	},
	{
		property: "simbMoeda",
		label: "Moeda",
	},
	{
		property: "vlrHonorario",
		label: "Valor honorários",
		type: 'number',
		format: "1.2-5",
	},
	{
		property: "vlrDespesa",
		label: "Valor despesas",
		type: 'number',
		format: "1.2-5",
	},
	{
		property: "descEscritorio",
		label: "Escritório",
	},
	{
		property: "revisores",
		label: "Revisor(es)",
	},
	{
		property: "icons",
		type: "icon",
		label: ' ',
		width: '5%',
		icons: []
	},
	{
		property: "errorMsg",
		label: "Erro",
		visible: false,
	}
];

/**
 * Estrutura do Grid para multiplos revisores da Pré faturas 
 */
export const gridPreFaturasMultRev: Array<PoTableColumn> = [
	{
		property: "chave",
		label: "Chave de pesquisa",
	},
	{
		property: "descParticipante",
		label: "Revisor",	
	},
	{
		property: "tipoRevisao",
		label: "Tipo da revisão",
	},
	{
		property: "action",
		type: "icon",
		width: "20%",
		label: "Ação",
		icons: [],
	},
];
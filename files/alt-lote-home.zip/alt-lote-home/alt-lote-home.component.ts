import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { PoComboComponent } from '@po-ui/ng-components';
import { Subscription, TeardownLogic } from 'rxjs';
import { adapterFilterParam, adapterReturnStruct, FwmodelAdapterService } from 'src/app/services/fwmodel-adapter.service';
import { FwAdapters } from 'src/app/shared/adapters/fw-adapters';
import { findValueByName, isNullOrUndefined } from 'src/app/shared/util-functions';
import { AltLoteDataProviderService } from '../alt-lote-data-provider.service';
import { TipoEntidadeAltLote } from './alt-lote-home.struct';
import { AltLoteWidgetEntidadeComponent } from './componentes/alt-lote-widget-entidade/alt-lote-widget-entidade.component';

@Component({
	selector: 'app-alt-lote-home',
	templateUrl: './alt-lote-home.component.html',
	styleUrls: ['./alt-lote-home.component.css']
})
export class AltLoteHomeComponent{
	codParticipante: string = undefined;
	runningSubscriptions: boolean = false;
	tipo: TipoEntidadeAltLote;
	lsSubscriptions: Array<Subscription> = [];
	tdVerifySubscriptions: TeardownLogic = () => {this.verifyIfAllSubscriptionsAreClosed()};
	adapterTodosParticipantes: adapterFilterParam = FwAdapters.adapterTodosParticipantes;

	@ViewChildren(AltLoteWidgetEntidadeComponent) allWidgets: QueryList<AltLoteWidgetEntidadeComponent>;
	@ViewChild("comboParticipante", { static: true }) cmbParticipante: PoComboComponent;

	constructor(public fwmodelAdapter: FwmodelAdapterService,
		private altLoteProvider: AltLoteDataProviderService,
		) {
	}

	ngAfterViewInit(): void {
		const codPartic: string = this.altLoteProvider.getParticipante().codigo

		if(!isNullOrUndefined(codPartic)) {
			this.codParticipante = codPartic;
			this.updateAll(false)
		}
	}

	/**
	 * Transforma a descrição no valor da Enum
	 * @param tipoEntidade - Descrição da Entidade
	 * @returns - TipoEntidadeAltLote - Enum do Tipo de Entidade
	 */
	returnTipoEntidade(tipoEntidade: string){
		return TipoEntidadeAltLote[tipoEntidade];
	}
	
	/**
	 * Atualiza as widgets
	 * @param updProvider - Indica se irá atualizar o campo de participante
	 */
	updateAll(updProvider: boolean = true){
		this.runningSubscriptions = true

		if (updProvider){
			const opcCmbPartExtra = (<adapterReturnStruct>this.cmbParticipante.selectedOption).getExtras();
			this.altLoteProvider.setParticipante({
				codigo: this.codParticipante,
				nome: this.cmbParticipante.selectedOption.label,
				sigla: findValueByName(opcCmbPartExtra, "RD0_SIGLA")
			})
		}
		
		this.allWidgets.forEach((widget)=>{
			this.lsSubscriptions.push(widget.updateData(this.codParticipante)?.add(this.tdVerifySubscriptions))
		})
	}

	/**
	 * Verifica se há requisição pendente para atualizar o Loading dos botões
	 */
	verifyIfAllSubscriptionsAreClosed(){
		this.runningSubscriptions = this.lsSubscriptions.filter(x=> !x.closed).length > 0;
	}
}

import { Component, HostListener, Input, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { PoModalComponent, PoNotificationService, PoTableAction, PoTableColumn, PoWidgetComponent } from "@po-ui/ng-components";
import { AltLoteDataProviderService } from "src/app/alteracao-lote/alt-lote-data-provider.service";
import { PfsAltLoteService } from "src/app/services/pfs-alt-lote.service";
import { PfsGenerics } from "src/app/services/pfsgenerics.service";
import { EventEmitter } from "stream";
import {
	IAltLoteEntity,
	IAltLoteFatura,
	IAltLoteFaturaAdicional,
	IAltLoteMultRevisores,
	IAltLotePreFatura,
	IAltLoteTimesheet,
	TipoConsultaAltLote,
	TipoEntidadeAltLote,
	TipoSituacaoAltLote,
} from "../../alt-lote-home.struct";
import { gridFatura, gridFaturaAdicional, gridPreFaturas, gridPreFaturasMultRev, gridTimesheet } from "../../alt-lote-grid-templates";
import { isNullOrUndefined } from "src/app/shared/util-functions";

@Component({
	selector: "pfs-alt-lote-widget-entidade",
	templateUrl: "./alt-lote-widget-entidade.component.html",
	styleUrls: ["./alt-lote-widget-entidade.component.css"],
})
export class AltLoteWidgetEntidadeComponent implements OnInit {
	_title: string = "";
	filterTela: string = "";
	searchKey: string = "";
	_quantidade: number = 0;
	_tipoConsulta: TipoConsultaAltLote = TipoConsultaAltLote.VISUALIZACAO;
	_endpoint: string = "";
	_entidade: TipoEntidadeAltLote;
	_situacao: TipoSituacaoAltLote = {} as TipoSituacaoAltLote;

	isRequestLoading: boolean = false;
	codParticipante: string = "";
	lsColumns: Array<PoTableColumn> = [];
	lsItens: Array<any> = [];
	nHeightMonitor: number = 0;
	sizeModal: string = "";

	isPrimary: boolean = false;
	primaryLabel: string = "Filtre um participante";
	primaryAction: EventEmitter;

	/**
	 * Define qual a entidade da Widget
	 */
	@Input("pfs-tipo-entidade") set setEntidade(entidade: TipoEntidadeAltLote) {
		this._entidade = entidade;
		this.prepareWidget(entidade);
	}

	/**
	 * Prepara a Widget para a Rotina
	 * @param entidade - Entidade a ser setada
	 */
	prepareWidget(entidade: TipoEntidadeAltLote) {
		this._tipoConsulta = TipoConsultaAltLote.VISUALIZACAO;
		switch (entidade) {
			case TipoEntidadeAltLote.CLIENTES:
				this._title = "Clientes";
				this._endpoint = "cliente";
				this._tipoConsulta = TipoConsultaAltLote.ALTERACAO;
				break;
			case TipoEntidadeAltLote.CONTRATOS:
				this._title = "Contratos";
				this._endpoint = "contrato";
				this._tipoConsulta = TipoConsultaAltLote.ALTERACAO;
				break;
			case TipoEntidadeAltLote.CASOS:
				this._title = "Casos";
				this._endpoint = "caso";
				this._tipoConsulta = TipoConsultaAltLote.ALTERACAO;
				break;
			case TipoEntidadeAltLote.TITULOS_RECEBER:
				this._title = "Títulos a receber pendentes";
				this._endpoint = "tituloReceber";
				break;
			case TipoEntidadeAltLote.TIMESHEETS:
				this._title = "Time Sheets pendentes";
				this._endpoint = "timeSheet";
				this.lsColumns = gridTimesheet;
				break;
			case TipoEntidadeAltLote.PREFATURAS:
				this._title = "Pré-faturas pendentes";
				this._endpoint = "preFatura";
				this._tipoConsulta = TipoConsultaAltLote.ALTERACAO;
				this.lsColumns = gridPreFaturas;
				break;
			case TipoEntidadeAltLote.FATURAS_ADICIONAL:
				this._title = "Faturas adicionais em aberto";
				this._endpoint = "faturaAdicional";
				this.lsColumns = gridFaturaAdicional;
				break;
			case TipoEntidadeAltLote.JUNCOES_CONTRATO:
				this._title = "Junções de Contratos";
				this._endpoint = "juncaoContrato";
				this._tipoConsulta = TipoConsultaAltLote.ALTERACAO;
				break;
			case TipoEntidadeAltLote.FATURAS:
				this._title = "Faturas em aberto";
				this._endpoint = "fatura";
				this.lsColumns = gridFatura;
				break;
			default:
				this._title = "=== ENTIDADE NÃO ENCONTRADA!!!!! ===";
				this._tipoConsulta = TipoConsultaAltLote.NENHUMA;
				break;
		}

		this.setAction();
	}

	/**
	 * Define a quantidade de itens em tela
	 */
	@Input("pfs-quantidade") set setQuantidade(quantidade: number) {
		this._quantidade = quantidade;
	}

	@ViewChild("modalVisualizacao", { static: false }) mdlVisualiza: PoModalComponent;
	@ViewChild(PoWidgetComponent) wdgMain: PoWidgetComponent;

	/**
	 * Responsável por realizar Resize da rotina
	 */
	@HostListener("window:load", ["$event"])
	@HostListener("window:resize", ["$event"])
	onResizeOrLoad(nQtdeCaracter: number) {
		this.nHeightMonitor = window.innerHeight * (window.innerHeight > 660 ? 0.6 : 0.45);
		if (nQtdeCaracter < 3000) {
			this.nHeightMonitor = this.nHeightMonitor * 0.5;
			this.sizeModal = "md";
		} else {
			this.nHeightMonitor = this.nHeightMonitor / 0.88;
			this.sizeModal = "auto";
		}
	}

	constructor(
		private pfsAltLote: PfsAltLoteService,
		private pfsGenerics: PfsGenerics,
		private poNotification: PoNotificationService,
		private route: Router,
		private activeRoute: ActivatedRoute,
		private altLoteProvider: AltLoteDataProviderService
	) {}

	ngOnInit(): void {}

	/**
	 * Define a ação da Widget
	 */
	setAction() {
		if (this.codParticipante === "") {
			this.primaryLabel = "Filtre um participante";
		} else if (this.isRequestLoading) {
			this.primaryLabel = "Carregando...";
		} else {
			switch (this._tipoConsulta) {
				case TipoConsultaAltLote.VISUALIZACAO:
					this.primaryLabel = "Ver lançamentos";
					break;
				case TipoConsultaAltLote.ALTERACAO:
					this.primaryLabel = "Alterar registros";
					break;
				default:
					break;
			}
		}
	}

	/**
	 * Realiza a ação da Widget
	 */
	callAction() {
		if (this.codParticipante === "" && this._tipoConsulta !== TipoConsultaAltLote.NENHUMA) {
			this.poNotification.information("Informe o participante!");
		} else {
			if (!this.isRequestLoading){
				switch (this._tipoConsulta) {
					case TipoConsultaAltLote.VISUALIZACAO:
						this.showGridEntidade();
						break;
					case TipoConsultaAltLote.ALTERACAO:
						this.redirectEditEntidade();
						break;
					default:
						break;
				}
			}
		}
	}

	/**
	 * Função para redirecionar para a alteração
	 */
	redirectEditEntidade() {
		this.route.navigate(["alteracao"], {
			relativeTo: this.activeRoute,
			queryParams: { entidade: this._entidade },
		});
	}

	/**
	 * Abre a modal
	 */
	showGridEntidade() {
		this.searchKey = ""
		this.mdlVisualiza.open();
	}

	/**
	 * Busca os valores de totalizadores da entidade
	 * @param codPart - Código do participante a filtrar
	 * @returns - Subscription - Observable da requisição
	 */
	getTotalizador(codPart: string) {
		this.isRequestLoading = true;
		this.setAction();
		this._quantidade = 0;
		this.pfsAltLote.restore();
		this.pfsAltLote.setQueryParam("qtdTotal", true);
		return this.pfsAltLote.get(this._endpoint + "/" + codPart, "Busca totalizadores", false).subscribe({
			next: (resp) => {
				this.isRequestLoading = false;
				this._quantidade = resp.total;
				if (this._quantidade === 0) {
					this.primaryLabel = "Não foram encontrados registros!";
					this._tipoConsulta = TipoConsultaAltLote.NENHUMA;
				} else {
					this.setAction();
				}
			},
			error: (error) => {
				this._quantidade = 0;
				this.primaryLabel = "Erro na requisição";
				this._tipoConsulta = TipoConsultaAltLote.NENHUMA;
			},
			complete: () => {
				this.isRequestLoading = false;
			},
		});
	}

	/**
	 * Busca os dados para os grids de visualização e alteração
	 * @param codPart - Código do participante
	 * @returns - Subscription - Observable da requisição
	 */
	getDados(codPart: string){
		this.lsItens = []
		this.pfsAltLote.restore();
		return this.pfsAltLote.get(this._endpoint + '/' + codPart, 'Busca de Fatura adicional', false).subscribe({
			next: async (resp: Array<any>)=>{
				// Verifica se houve retorno
				if (Object.keys(resp).length > 0){
					await resp.forEach(
						(item)=>{
							let novoItem: IAltLoteEntity = this.transformResult(item)
							this.lsItens.push(novoItem)
						}
					)

					this.altLoteProvider.addData(this._entidade, this.lsItens)
				} else {
					// Manda um array vazio para sobrescrever o que foi pesquisado antes
					this.altLoteProvider.addData(this._entidade, [])
				}
			},
		})
	}

	/**
	 * Função para chamar a atualização da Widget
	 * @param codPart - Código do Participante a ser buscado
	 * @returns - Subscription - Requisição do Totalizador para controle na Home
	 */
	updateData(codPart: string) {
		this.prepareWidget(this._entidade);
		this.codParticipante = codPart;
		this.getDados(codPart);

		return this.getTotalizador(codPart);
	}

	/**
	 * Monta a descrição de multiplos revisores
	 * @param multRevisores - Lista de multiplos revisores
	 * @returns 
	 */
	getDescRevisorMult(multRevisores: Array<IAltLoteMultRevisores>){
		multRevisores.forEach(item => {
			if(!isNullOrUndefined(item.participante.nome)){
				item.descParticipante = item.participante.nome.trim();
			}else {
				item.descParticipante = ""
			}
			item.action = ["edit"]
		});
		return multRevisores;
	}


	/**
	* Função para mostrar o código e legenda da propriedade Situação, na tela
	* @param codSituacao - Código da situação
	* @returns strSituacao - String com o código e legenda da situação
	*/
	transformSituacao(codSituacao) {
		let strSituacao = "";
		switch (codSituacao) {
			case '2':
				strSituacao = TipoSituacaoAltLote.ANALISE;
				return strSituacao;
			case '3':
				strSituacao = TipoSituacaoAltLote.ALTERADA;
				return strSituacao;
			case '7':
				strSituacao = TipoSituacaoAltLote.MINUTA_CANCELADA;
				return strSituacao;
			case 'C':
				strSituacao = TipoSituacaoAltLote.EM_REVISAO;
				return strSituacao;
			case 'E':
				strSituacao = TipoSituacaoAltLote.REVISADA_COM_RESTRICOES;
				return strSituacao;
			case 'B':
				strSituacao = TipoSituacaoAltLote.MINUTA_SOCIO_CANCELADA;
				return strSituacao;
			default:
				strSituacao = "";
		}
	}

	/**
	 * Transforma os dados da requisição para a estrutura da entidade
	 * @param data - Dados da requisição
	 * @returns - IAltLoteEntity - Dados estruturados da Entidade
	 */
	transformResult(data: any): IAltLoteEntity {
		switch (this._entidade) {
			case TipoEntidadeAltLote.CLIENTES:
				return {} as IAltLoteEntity;
			case TipoEntidadeAltLote.CONTRATOS:
				return {} as IAltLoteEntity;
			case TipoEntidadeAltLote.CASOS:
				return {} as IAltLoteEntity;
			case TipoEntidadeAltLote.TITULOS_RECEBER:
				return {} as IAltLoteEntity;
			case TipoEntidadeAltLote.TIMESHEETS:
				const novoTS: IAltLoteTimesheet = {
					codigo: data.codigo,
					data: this.pfsGenerics.makeDate(data.data, "dd/mm/yyyy"),
					codSolicitante: data.codPartSolic,
					nomeSolicitante: data.nomePartSolic,
					siglaSolicitante: data.siglaPartSolic,
					codRevisor: data.codPartRevis,
					nomeRevisor: data.nomePartRevis,
					siglaRevisor: data.siglaPartRevis,
					codCliente: data.codCliente,
					lojaCliente: data.lojaCliente,
					cliente: data.cliente,
					codCaso: data.codCaso,
					tituloCaso: data.tituloCaso,
					codAtividade: data.codAtividade,
					descAtividade: data.descAtividade,
					horaLancada: data.horaLancada,
					horaRevisada: data.horaRevisada,
					UTLancada: data.UTLancada,
					UTRevisada: data.UTRevisada,
					cobrar: data.cobrar == "2",
					codMoeda: data.codMoeda,
					simboloMoeda: data.simbMoeda,
					descMoeda: data.descMoeda,
					valorTS: data.valorTS,
					descricTS: data.descTS,
				};
				return novoTS;
				case TipoEntidadeAltLote.PREFATURAS:
					const novaPreFatura: IAltLotePreFatura = {
						codigo: data.codigo,
						situacao: this.transformSituacao(data.situacao),
						dataEmissao: this.pfsGenerics.makeDate(data.dataEmissao, "dd/mm/yyyy"),
						vlrHonorario: data.vlrHonorario,
						vlrDespesa: data.vlrDespesa,
						codEscritorio: data.codEscritorio,
						codCliente: data.codCliente,
						codLoja: data.codLoja,
						codContr: data.codContr,
						capa: data.capa,
						descEscritorio: data.descEscritorio,
						descMoeda: data.descMoeda,
						simbMoeda: data.simbMoeda,
						contratos: data.contratos,
						casos: data.casos,
						revisores: AltLoteDataProviderService.uniteMultiplos(data.capa, data.multRevisores),
						multRevisores: this.getDescRevisorMult(data.multRevisores),
						icons: [],
						errorMsg: ''
					};
					return novaPreFatura;
			case TipoEntidadeAltLote.FATURAS_ADICIONAL:
				const novaFaturaAdic: IAltLoteFaturaAdicional = {
					codigo: data.codigo,
					database: this.pfsGenerics.makeDate(data.database, "dd/mm/yyyy"),
					codGrupo: data.codGrupo,
					descGrupo: data.descGrupo,
					codCliente: data.codCliente,
					lojaCliente: data.lojaCliente,
					cliente: data.cliente,
					codContrato: data.codContrato,
					nomeContrato: data.nomeContrato,
					valorTS: data.valorTS,
					valorTabelado: data.valorTabelado,
					valorDespesa: data.valorDespesa,
					valorDespesaTrib: data.valorDespesaTrib,
					valorTotal: data.valorTS + data.valorTabelado + data.valorDespesa + data.valorDespesaTrib,
					faturaAdicionalOcorrencia: data.flagOcorrencia == "2",
				};
				return novaFaturaAdic;
			case TipoEntidadeAltLote.JUNCOES_CONTRATO:
				return {} as IAltLoteEntity;
			case TipoEntidadeAltLote.FATURAS:
				const novaFatura: IAltLoteFatura = {
					codigo: data.codigo,
					quantidadeTitulosReceber: data.quantTitulos,
					dataEmissao: this.pfsGenerics.makeDate(data.dataEmissao, "dd/mm/yyyy"),
					codMoeda: data.codMoeda,
					descMoeda: data.descMoeda,
					valorHonorario: data.valorHonorario,
					valorDespesas: data.valorDespesa,
					codigoEscritorio: data.codEscritorio,
					descEscritorio: data.nomeEscritorio,
					codParticipante: data.codParticipante,
					siglaParticipante: data.siglaParticipante,
					nomeParticipante: data.nomeParticipante,
					saldoFatura: data.saldoFatura,
				};
				return novaFatura;
			default:
				return {} as IAltLoteEntity;
		}
	}
}

import { Pipe, PipeTransform } from "@angular/core";
import { removeAcentos } from "src/app/shared/util-functions";

/**
 * Pipe criado para realizar o filtro dos campos
 * @param name Nome do Pipe
 */
@Pipe({ name: "filtroTelaAltLote" })
export class FiltroTelaAltLotePipe implements PipeTransform {
	transform(itemList: Array<any>, valor: string = "") {
		valor = valor.trim().toLowerCase();

		if (valor) {
			return itemList.filter((item) => this.filtraColunas(item, valor));
		} else {
			return itemList;
		}
	}

	/**
	 * Filtra a descrição conforme o conteúdo digitado
	 * Pesquisa somente em campos que não sejam do tipo numérico
	 * @param item - Linha do grid
	 * @param valor - texto digitado no campo de palavra chave
	 */
	filtraColunas(item: any, valor: string) {
		let contem: boolean = false;
		Object.keys(item).forEach((element) => {
			for (const coluna in item) {
				if (item.hasOwnProperty(coluna)) {
					// Não considera os campos numéricos
					if (typeof item[coluna] === "string" || typeof item[coluna] === "boolean") {
						let dado: string = "";
						// Trata campo boolean
						if (typeof item[coluna] === "boolean") {
							dado = item[coluna] ? "Sim" : "Não";
						}else{
							dado = item[coluna];
						}

						contem = removeAcentos(dado).includes(removeAcentos(valor));

						if (contem) {
							return contem;
						}
					}
				}
			}
		});
		return contem;
	}
}

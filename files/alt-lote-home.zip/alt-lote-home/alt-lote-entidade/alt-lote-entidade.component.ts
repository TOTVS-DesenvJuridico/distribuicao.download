import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { PoComboComponent, PoDisclaimer, PoModalAction, PoModalComponent, PoTableColumn, PoTableComponent } from "@po-ui/ng-components";
import { adapterFilterParam, adapterReturnStruct, FwmodelAdapterService } from "src/app/services/fwmodel-adapter.service";
import { IAltLoteEntity, IAltLoteMultRevisores, IAltLoteParticipante, IAltLotePreFatura, IAltLoteSubmit, TipoEntidadeAltLote } from "../alt-lote-home.struct";
import { gridPreFaturas, gridPreFaturasMultRev } from "../alt-lote-grid-templates";
import { Color } from "src/app/shared/info-box/info-box.component";
import { AltLoteDataProviderService } from "../../alt-lote-data-provider.service";
import { findColumnIndex, findValueByName, isNullOrUndefined } from "src/app/shared/util-functions";
import { FwAdapters } from "src/app/shared/adapters/fw-adapters";
import { PfsAltLoteService } from "src/app/services/pfs-alt-lote.service";

@Component({
	selector: "app-alt-lote-entidade",
	templateUrl: "./alt-lote-entidade.component.html",
	styleUrls: ["./alt-lote-entidade.component.css"],
})
export class AltLoteEntidadeComponent implements OnInit {
	_entidade: TipoEntidadeAltLote;
	_endpoint: string = "";
	_gridTitle: string = "";
	_participante: IAltLoteParticipante;
	newPartFullReplace: IAltLoteParticipante = {} as IAltLoteParticipante;

	strVarPartSelected: string = ""; // Variavel de controle para a origem do participante
	partSelected: IAltLoteParticipante = {} as IAltLoteParticipante;
	partBatchSelected: IAltLoteParticipante = {} as IAltLoteParticipante;

	titulo: string = "Alteração em Lote - ";
	title: string = "";
	title_compl: string = "";

	palavraChave: string = "";
	filterTela: string = "";
	searchKey: string = "";
	colorInfo: Color = Color.blue;
	colorInfoBatch: Color = Color.red;
	txtInfoPartDest: string = "";
	txtInfoConfirmBatch: string = "";

	codParticipante: string = "";
	codPartBatch: string = "";
	newParticipante: string = "";
	runningSubscriptions: boolean = false;
	
	listDisclaimer: Array<PoDisclaimer> = [];
	lsColumns: Array<PoTableColumn> = [];
	lsColumnsMultRev: Array<PoTableColumn> = gridPreFaturasMultRev;
	lsItens: Array<IAltLoteEntity> = [];

	dadosRevisor: IAltLoteMultRevisores;
	multRevEnabled: boolean = false;

	actMdlBatchPrimary: PoModalAction = {
		label: "Confirmar",
		action: ()=> { this.confirmBatchChange() }
	}

	actMdlBatchSecondary: PoModalAction = {
		label: "Cancelar",
		action: ()=> { this.cancelBatchChange() }
	}

	adapterPartAltLote: adapterFilterParam = FwAdapters.adapterParticipante;

	@ViewChild("tableMain", { static: true }) tbmMain: PoTableComponent;
	@ViewChild("modalBatchConfirm", { static: false }) mdlBatchConf: PoModalComponent;
	@ViewChild("modalEditarMultiploRev", { static: false }) mdlEditar: PoModalComponent;
	@ViewChild("comboPartDestLote", { static: true }) cmbPartDestLote: PoComboComponent;
	@ViewChild("comboRevisor", { static: false }) cmbRevisor: PoComboComponent;
	@ViewChild("comboPartMultRev", { static: false }) cmbPartMultRev: PoComboComponent;

	constructor(
		private route: Router, 
		private activeRouter: ActivatedRoute, 
		public fwmodelAdapter: FwmodelAdapterService,
		private altLoteProvider: AltLoteDataProviderService,
		private pfsAltLoteApi: PfsAltLoteService,
	) {
		this._participante = this.altLoteProvider.getParticipante()
		if (isNullOrUndefined(this._participante.codigo)){
			this.voltar()
		}

		this._entidade = TipoEntidadeAltLote[this.activeRouter.snapshot.queryParamMap.get("entidade")];
		this.prepareWidget(this.activeRouter.snapshot.queryParamMap.get("entidade"));
	}

	ngOnInit(): void {}

	/**
	 * Retorna os dados do Participante selecionado
	 * @returns 
	 */
	getDadosPartSelecionado(): IAltLoteParticipante{
		return this[this.strVarPartSelected]
	}

	/**
	 * Inclui os icones no grid
	 */
	setIcons(){
		this.lsColumns[findColumnIndex(this.lsColumns,"icons")].icons = [
			{ 
				value: "error", 
				color: 'color-07',
				icon: "po-icon-exclamation",
				tooltip: "Clique para visualizar o erro",
				action: () => {this.showError()},
			},
			{
				value: "success",
				color: 'color-12',
				icon: "po-icon-exclamation",
				tooltip: "Alteração realizada com sucesso!"
			}
		]

		this.lsColumnsMultRev[3].icons = [
			{ 
				value: "edit", 
				icon: "po-icon-edit",
				tooltip: "Editar",
				action: (value) => {this.openModal(value)},
			},
			{
				value: "delete",
				icon: "po-icon-delete",
				tooltip: "Excluir",
				action: (value) => {}
			}
		]
	}

	/**
	 * Define se irá mostrar a coluna de erro
	 */
	showError(visible: boolean = !this.lsColumns[findColumnIndex(this.lsColumns, "errorMsg")].visible){
		this.lsColumns[findColumnIndex(this.lsColumns, "errorMsg")].visible = visible;
		this.lsColumns = [...this.lsColumns];
	}

	/**
	 * Monta o Título da pagina
	 */
	makeTitle(){
		this.titulo = "Alteração em Lote - " + this.title + this.title_compl + " [" + this._participante.sigla + "] " + this._participante.nome
	}

	/**
	 * Prepara a Widget para a Rotina
	 * @param entidade - Entidade a ser setada
	 */
	prepareWidget(entidade: string) {
		switch (TipoEntidadeAltLote[entidade]) {
			case TipoEntidadeAltLote.CLIENTES:
				this._endpoint = "cliente";
				this._gridTitle = "Clientes relacionados";
				this.title = "Clientes";
				break;
			case TipoEntidadeAltLote.CONTRATOS:
				this._endpoint = "contrato";
				this._gridTitle = "Contratos relacionados";
				this.title = "Contratos";
				break;
			case TipoEntidadeAltLote.CASOS:
				this._endpoint = "caso";
				this._gridTitle = "Casos relacionados";
				this.title = "Casos";
				break;
			case TipoEntidadeAltLote.TITULOS_RECEBER:
				this._endpoint = "tituloReceber";
				this._gridTitle = "Títulos a receber relacionados";
				this.title = "Títulos a receber";
				this.title_compl = " pendentes"
				break;
			case TipoEntidadeAltLote.PREFATURAS:
				this._endpoint = "preFatura";
				this._gridTitle = "Pré-faturas relacionados";
				this.title = "Pré-faturas";
				this.title_compl = " pendentes"
				this.lsItens = [...this.altLoteProvider.getData(this._entidade)];
				this.lsColumns = gridPreFaturas;
				break;
			default:
				this.title = "=== ENTIDADE NÃO ENCONTRADA!!!!! ===";
				break;
		}
		this.setInfoBox();
		this.enableMultiplos();
		this.makeTitle();
		this.setIcons();
	}

	/**
	 * Verifica se utiliza os multiplos revisores ou não
	 */
	enableMultiplos(){
		const MV_JMULTRV = this.altLoteProvider.getParamValue('MV_JMULTRV')
		this.multRevEnabled = MV_JMULTRV
	}
	
	/**
	 * Define o texto dos InfoBoxs da tela
	 */
	setInfoBox(){
		this.txtInfoPartDest = "Ao preencher o participante destino, os registros abaixo serão relacionados a ele. " +
							   "Para escolher participantes diferentes para cada registro utilize o lápis na tabela. " +
							   "Os registros só serão alterados ao clicar em Salvar Alterações.";
		this.txtInfoConfirmBatch = "As alterações que serão executadas não são finais! " +
								   "Para salva-las é necessário salvar as operações no final da tela. " +
								   "Aconselha-se tambem que o usuário verifique as alterações."
	}

	/**
	 * Confirma a atualização em Lote
	 */
	confirmBatchChange(){
		this.updateAllEntity()
	}

	/**
	 * Cancela a operação em Lote
	 */
	cancelBatchChange(){
		this.codPartBatch = "";
		this.mdlBatchConf.close();
	}

	/**
	 * Prepara os dados para a alteração em lote
	 * @param opcCodSelecionado - Código do participante selecionado
	 */
	startFullPartReplace(opcCodSelecionado: string){
		if (opcCodSelecionado !== undefined){
			this.changeSelectedPart(opcCodSelecionado, "cmbPartDestLote", "partBatchSelected")
			this.mdlBatchConf.open()
		}
	}

	/**
	 * Realiza a atualizaçao dos dados para o Participante principal selecionado
	 */
	async updateAllEntity(){
		await this.lsItens.forEach((line, index)=>{
			this.updateMainGrid(line, index)
		})
		this.mdlBatchConf.close();
	}

	/**
	 * Realiza os envio dos dados para o endpoint
	 */
	submit() {
		this.lsItens.forEach((item, index)=>{
			if (!item.success){
				item.icons = [];
				item.errorMsg = ""
				this.showError(false)

				const body = this.buildBody(index)
				this.pfsAltLoteApi.restore();
				this.pfsAltLoteApi.put('revisor/' + this._endpoint + "/" + btoa(this._participante.codigo), 
					JSON.stringify(body), 
					'Alteração em Lote ' + this.title + " " + item.codigo, 
					false).subscribe({
						next: (resp)=>{
							this.lsItens[index].icons.push('success')
							this.lsItens[index].success = true;
						},
						error: (error)=>{
							this.lsItens[index].errorMsg = error.error.errorMessage
							this.lsItens[index].icons.push('error')
						}
					}
				)
			}
		})
	}

	/**
	 * Inicia o Body da requisição
	 * @param index - Indice da linha a ser montada
	 * @returns 
	 */
	buildBody(index: number): IAltLoteSubmit{
		const lnObject = JSON.parse(JSON.stringify(this.lsItens[index]))
		switch (this._entidade) {
			case TipoEntidadeAltLote.PREFATURAS:
				return this.buildBodyPreFat(lnObject);
			default:
				return null;
		}
	}

	/**
	 * Monta o Body para a requisição da pré-fatura
	 * @param lnPreFat - Linha da pré-fatura
	 * @returns 
	 */
	buildBodyPreFat(lnPreFat: IAltLotePreFatura): IAltLoteSubmit{
		let bodyPreFat: IAltLoteSubmit = {} as IAltLoteSubmit;
		let arrCamposAlt: Array<string> = []

		bodyPreFat.chave = btoa(lnPreFat.codigo)

		// Verifica se o revisor foi alterado
		if (lnPreFat.capa.updated){
			bodyPreFat.revisor = {
				codigo: lnPreFat.capa.codigo
			}
			arrCamposAlt.push('revisor')
		}

		// Verifica se o multiplo revisor foi alterado
		if (this.multRevEnabled && lnPreFat.multRevisores.length > 0){
			bodyPreFat.multiplos = []
			lnPreFat.multRevisores.forEach((revisor, indMultRev)=>{
				bodyPreFat.multiplos.push({
					id: indMultRev,
					chave: btoa(revisor.chave),
					updated: revisor.participante.updated,
					deleted: revisor.participante.deleted,
					participante: revisor.participante.codigo
				})
				// Caso tenhha sido atualizado, indica no body que houve mudança
				if ((revisor.participante.updated || revisor.participante.deleted)){
					if (arrCamposAlt.findIndex(x => x === 'multiplo') === -1){
						arrCamposAlt.push('multiplo')
					}
				}
			})
		}
		bodyPreFat.campoAlterado = [...arrCamposAlt]
		return bodyPreFat;
	}

	/**
	 * Ação do botão voltar. Retorna para a rota da home.
	 */
	voltar(){
		this.route.navigate(["./main/alteracao-lote"]);

	}

	/**
	 * Reinicia as principais variáveis quando expandir a proxima linha
	 */
	initExpanded(){
		this.partSelected = undefined;
	}

	/**
	 * Atualiza o sócio / revisor
	 * @param row - Objeto de atributos da linha selecionada
	 * @param rowIndex - Index da linha posicionada
	 */
	updateMainGrid(row: any, rowIndex: number) {
		const partSelected = this.getDadosPartSelecionado();

		if(!isNullOrUndefined(partSelected.codigo)){
			switch (this._entidade) {
				case TipoEntidadeAltLote.PREFATURAS:
					this.updateRevisorPreFat(row);
					break;
				default:
					console.error("======= ENTIDADE NÃO IMPLEMENTADA! =======")
					break;
			}
			this.tbmMain.collapse(rowIndex)
		}
	}

	/**
	 * Atualiza o Revisor quando a entidade for Pre-fatura
	 * @param row - Linha posicionada
	 */
	updateRevisorPreFat(row: IAltLotePreFatura){
		const index: number = this.lsItens.findIndex(x => x.codigo === row.codigo);
		const partSelected = this.getDadosPartSelecionado();
		if(index > -1){
			if (row.capa.codOriginal === this._participante.codigo){
				row.capa.codigo = partSelected.codigo
				row.capa.nome = partSelected.nome
				row.capa.sigla = partSelected.sigla
				row.capa.updated = true;
			}
			if (this.multRevEnabled && row.multRevisores.length > 0){
				this.updateMultRevPart(row)
			}

			row.revisores = AltLoteDataProviderService.uniteMultiplos(row.capa, row.multRevisores)
			this.lsItens[index] = row;
		}
	}

	/**
	 * Aber a modal de Alteração do Multiplo Revisor
	 * @param value - Linha do Revisor a ser alterado
	 */
	openModal(value: IAltLoteMultRevisores){
		this.mdlEditar.open();
		this.dadosRevisor = value;
	}

	/**
	 * Ação do botão Voltar do modal. Fecha o modal.
	 */
	fecharModal(){
		this.mdlEditar.close();
	}

	/**
	 * Guarda o Participante selecionado para utilizar na atualização tanto do Grid quanto do Revisor
	 * @param codPartSelecionado - Código do Participante
	 * @param varComboPart - Nome da variável do Combo criado no ViewChild
	 * @param varPartSelected - Nome da Variável que receberá os dados do participante
	 */
	changeSelectedPart(codPartSelecionado: string, varComboPart: string, varPartSelected: string = "partSelected"){
		if (codPartSelecionado != undefined) {
			this.strVarPartSelected = varPartSelected
			const cmbPartExtra = (<adapterReturnStruct>this[varComboPart].selectedOption).getExtras();
			this[varPartSelected] = {
				codigo: codPartSelecionado,
				nome: this[varComboPart].selectedOption.label,
				sigla: (findValueByName(cmbPartExtra, "RD0_SIGLA"))
			}
		} else {
			this[varPartSelected] = {} as IAltLoteParticipante;
		}
	}

	/**
	 * Ação do botão Salvar do modal. Carrega os dados do modal para a estrutura principal.
	 * @param rowItem - Linha posicionada
	 */
	updateMultRevPart(rowItem: IAltLoteEntity) {
		const cmbPartSel = this.getDadosPartSelecionado()
		if(!isNullOrUndefined(cmbPartSel.codigo)){
			const index: number = this.lsItens.findIndex(x => x.codigo === rowItem.codigo);

			if(index > -1){
				const indexMultRev: number = rowItem.multRevisores.findIndex(x => x.participante.codOriginal === this._participante.codigo);
				if (indexMultRev > -1 && !this.markRevisorAsDeleted(rowItem)){
					this.lsItens[index] = this.convertRowForEntityMultRev(rowItem, indexMultRev);
				}
			}
		}
	}

	/**
	 * Atualiza os multiplos revisores para deletado
	 * @param rowItem - Linha da pré-fatura
	 * @returns 
	 */
	markRevisorAsDeleted(rowItem: IAltLoteEntity){
		const partSelected = this.getDadosPartSelecionado();
		const lNewRevExisteMultRev = rowItem.multRevisores.filter((rev)=> rev.participante.codOriginal === partSelected.codigo).length > 0

		if (lNewRevExisteMultRev){
			rowItem.multRevisores.forEach((revisor, index, arrRevisor)=>{
				if (!revisor.participante.deleted && 
					revisor.participante.codOriginal === this._participante.codigo){
					revisor.participante.deleted = true;
				}
			})
		} else {
			rowItem.multRevisores.forEach((revisor)=>{
				revisor.participante.deleted = false;
			})
		}
		return lNewRevExisteMultRev
	}

	/**
	 * Converte os dados de Multiplos revisores para a entidade
	 * @param row - Dados da Linha
	 * @param indexMultRev - Indice a ser alterado
	 * @returns Entidade atualizada com o novo participante
	 */
	convertRowForEntityMultRev(row: any, indexMultRev: number ): IAltLoteEntity{
		switch (this._entidade) {
			case TipoEntidadeAltLote.PREFATURAS:
				let currentRow: IAltLotePreFatura = row
				const partSelected = this.getDadosPartSelecionado();
				currentRow.multRevisores[indexMultRev].participante.codigo = partSelected.codigo;
				currentRow.multRevisores[indexMultRev].participante.nome = partSelected.nome;
				currentRow.multRevisores[indexMultRev].participante.sigla = partSelected.sigla;
				currentRow.multRevisores[indexMultRev].participante.updated = true;
				currentRow.multRevisores[indexMultRev].descParticipante = partSelected.nome;
				currentRow.revisores = AltLoteDataProviderService.uniteMultiplos(row.capa, row.multRevisores);
				return currentRow
			default:
				console.error("======= ENTIDADE NÃO IMPLEMENTADA! =======")
				return {} as IAltLoteEntity
		}
	}

}

/**
 * Enum das entidades presentes na tela
 */
export enum TipoEntidadeAltLote {
	CLIENTES = "CLIENTES",
	CONTRATOS = "CONTRATOS",
	CASOS = "CASOS",
	TITULOS_RECEBER = "TITULOS_RECEBER",
	TIMESHEETS = "TIMESHEETS",
	PREFATURAS = "PREFATURAS",
	FATURAS_ADICIONAL = "FATURAS_ADICIONAL",
	JUNCOES_CONTRATO = "JUNCOES_CONTRATO",
	FATURAS = "FATURAS",
}

/**
 * Tipo de ação a ser realizada na Widget
 */
export enum TipoConsultaAltLote {
	NENHUMA = "NENHUMA",
	VISUALIZACAO = "VISUALIZACAO",
	ALTERACAO = "ALTERACAO",
}

/*
* Enum da propriedade Situação, na ela
*/
export enum TipoSituacaoAltLote {
	ANALISE = "2 - Análise",
	ALTERADA = "3 - Alterada",
	MINUTA_CANCELADA = "7 - Minuta cancelada",
	EM_REVISAO = "C - Em revisão",
	REVISADA_COM_RESTRICOES = "E - Revisada com restrições",
	MINUTA_SOCIO_CANCELADA = "B - Minuta sócio cancelada",
}

/**
 *  Interface para extensão dos dados da entidade
 */
export interface IAltLoteEntity {
	codigo: string;
	multRevisores?: Array<IAltLoteMultRevisores>;
	icons?: Array<string>;
	errorMsg?: string;
	success?: boolean;
}

/**
 * Estrutura para a Fatura Adicional
 */
export interface IAltLoteFaturaAdicional extends IAltLoteEntity {
	database: string;
	codGrupo: string;
	descGrupo: string;
	codCliente: string;
	lojaCliente: string;
	cliente: string;
	codContrato: string;
	nomeContrato: string;
	valorTS: number;
	valorTabelado: number;
	valorDespesa: number;
	valorDespesaTrib: number;
	valorTotal: number;
	faturaAdicionalOcorrencia: boolean;
}

/**
 * Estrutura para o Timesheet
 */
export interface IAltLoteTimesheet extends IAltLoteEntity {
	data: string;
	codSolicitante: string;
	nomeSolicitante: string;
	siglaSolicitante: string;
	codRevisor: string;
	nomeRevisor: string;
	siglaRevisor: string;
	codCliente: string;
	lojaCliente: string;
	cliente: string;
	codCaso: string;
	tituloCaso: string;
	codAtividade: string;
	descAtividade: string;
	horaLancada: string;
	horaRevisada: string;
	UTLancada: string;
	UTRevisada: string;
	cobrar: boolean;
	codMoeda: string;
	simboloMoeda: string;
	descMoeda: string;
	valorTS: number;
	descricTS: string;
}

/**
 * Estrutura para o Título a Receber
 */
export interface IAltLoteTituloReceber extends IAltLoteEntity {}

/**
 * Estrutura para a Fatura
 */
export interface IAltLoteFatura extends IAltLoteEntity {
	quantidadeTitulosReceber: number;
	dataEmissao: string;
	codMoeda: string;
	descMoeda: string;
	valorHonorario: number;
	valorDespesas: number;
	codigoEscritorio: string;
	descEscritorio: string;
	codParticipante: string;
	siglaParticipante: string;
	nomeParticipante: string;
	saldoFatura: number;
}

/**
 * Estrutura para a Pré-fatura
 */
export interface IAltLotePreFatura extends IAltLoteEntity {
	situacao: string;
	dataEmissao: string;
	vlrHonorario: number;
	vlrDespesa: number;
	codEscritorio: string;
	codCliente: string;
	codLoja: string;
	codContr: string;
	capa: IAltLoteParticipante;
	descEscritorio: string;
	descMoeda: string;
	simbMoeda: string;
	contratos: string;
	casos: string;
	revisores?: string;
}

/**
 * Estrutura para um Participante
 */
export interface IAltLoteParticipante {
	codigo: string;
	nome?: string;
	sigla?: string;
	updated?: boolean;
	deleted?: boolean;
	codOriginal?: string;
}

/**
 * Estrutura para Múltiplos Revisores
 */
export interface IAltLoteMultRevisores {
	chave: string;
	participante: IAltLoteParticipante;
	tipoRevisao: string;
	descParticipante?: string;
	action?: Array<string>;
}

/**
 * Estrutura para envio para o Endpoint
 */
export interface IAltLoteSubmit{
	chave: string,
	campoAlterado: Array<string>,
	revisor?: {
		codigo: string
	},
	socio?: {
		codigo: string
	},
	multiplos?: Array<{
		id: number,
		deleted: boolean,
		updated: boolean,
		chave: string,
		participante: string
	}>
}